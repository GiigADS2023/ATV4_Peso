﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace While2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Escreva um programa que pergunte ao usuário quantos alunos ele
            tem em sua academia. Em seguida, através de um laço while, o usuário
            digita o peso de todos os alunos, um por vez, e por fim, o programa deve
            mostrar a média de peso dos clientes.*/

            //Step 1, pergunte ao usuário quantos alunos ele tem em sua academia.
            Console.WriteLine("Digite a quantidade de alunos em sua academia");
            int alunos = int.Parse(Console.ReadLine());
            int cliente = 1;
            float somadospesos = 0;

            while (cliente <= alunos)
            {
                //Step 2, digita o peso de todos os alunos
                Console.WriteLine("Digite o peso do " + cliente + "º cliente");
                float peso = float.Parse(Console.ReadLine());
                somadospesos += peso;
                cliente++;  
            }
            //Step 3, mostrar a média de peso dos clientes
            double mediadospesos = somadospesos / alunos;
            Console.WriteLine("A média dos pesos ficou: " + mediadospesos);
            Console.ReadLine();

            Console.WriteLine("Agradecemos pelo uso do nosso programa ^^.");
            Console.ReadLine();
        }
    }
}

/*
 USING FOR 
 * // Step 1, pedir ao usuário que digite o número de clientes
Console.WriteLine("Quantos clientes deseja cadastrar?");
int clientes = int.Parse(Console.ReadLine());

// Step 2, pedir ao usuário que digite o peso de cada cliente e somar os pesos
float somaDosPesos = 0;
for (int i = 1; i <= clientes; i++)
{
    Console.WriteLine("Digite o peso do " + i + "º cliente:");
    float peso = float.Parse(Console.ReadLine());
    somaDosPesos += peso;
}

// Step 3, calcular e mostrar a média de peso dos clientes
double mediaDosPesos = somaDosPesos / clientes;
Console.WriteLine("A média dos pesos ficou: " + mediaDosPesos);
Console.ReadLine();
*/
